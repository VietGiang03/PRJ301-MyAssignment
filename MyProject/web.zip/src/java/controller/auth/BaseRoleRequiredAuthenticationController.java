package controller.auth;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Role;
import model.User;

public abstract class BaseRoleRequiredAuthenticationController extends HttpServlet {
    
    private boolean hasRequiredRoleId(User user, int requiredRoleId) {
        for (Role role : user.getRoles()) {
            if (role.getId() == requiredRoleId) {
                return true;
            }
        }
        return false;
    }

    private boolean isAuthenticated(HttpServletRequest request, int requiredRoleId) {
        User user = (User) request.getSession().getAttribute("user");
        if (user == null) {
            return false;
        } else {
            return hasRequiredRoleId(user, requiredRoleId);
        }
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int requiredRoleId = getRequiredRoleId();
        if (isAuthenticated(request, requiredRoleId)) {
            User user = (User) request.getSession().getAttribute("user");
            doGet(request, response, user);
        } else {
            response.getWriter().println("access denied!");
        }
    }
    
    protected abstract void doGet(HttpServletRequest request, HttpServletResponse response, User user)
            throws ServletException, IOException;
    
    protected abstract void doPost(HttpServletRequest request, HttpServletResponse response, User user)
            throws ServletException, IOException;
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int requiredRoleId = getRequiredRoleId();
        if (isAuthenticated(request, requiredRoleId)) {
            User user = (User) request.getSession().getAttribute("user");
            doPost(request, response, user);
        } else {
            response.getWriter().println("access denied!");
        }
    }
    
    protected abstract int getRequiredRoleId();
    
    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
